# Prasannashree K — Portfolio

A static site. No build step, no dependencies to install.

## Run locally

Pick one:

**Option 1 — just open it**
Double-click `index.html` (or right-click → Open with your browser).

**Option 2 — local server (recommended, avoids font/asset quirks)**
```bash
# Python
python3 -m http.server 5500

# Node (if you have it)
npx serve .
```
Then visit `http://localhost:5500` in your browser.

**Option 3 — VS Code**
Install the "Live Server" extension, right-click `index.html` → "Open with Live Server".

## Deploy

Same as the AI BugFix project — this is plain HTML/CSS/JS, so it drops straight into:
- Amazon S3 static website hosting
- Netlify / Vercel (drag-and-drop the folder)
- GitHub Pages

## Files

```
portfolio/
├── index.html   → structure & content
├── style.css    → design system, layout, animations
├── script.js    → scroll reveals, mobile menu, stat counter
└── README.md    → this file
```

## Notes

- No résumé or LinkedIn link is included since none was supplied — add them in the
  hero CTA (`.hero__cta`) and contact section (`.contact__links`) in `index.html`
  whenever they're ready.
- The SAP Delivery Control Cockpit project card has no GitHub button because that
  repository link wasn't provided — add one in the `.project__links` markup for
  that project if the repo becomes public.
