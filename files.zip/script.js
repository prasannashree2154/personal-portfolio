// ===========================================================
// Reveal on scroll
// ===========================================================
const revealEls = document.querySelectorAll('.reveal, .reveal-up');
const io = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('in-view');
      io.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });
revealEls.forEach(el => io.observe(el));

// Hero reveals immediately on load (no scroll needed)
window.addEventListener('load', () => {
  document.querySelectorAll('.hero .reveal').forEach(el => el.classList.add('in-view'));
});

// ===========================================================
// Sticky nav + mobile menu
// ===========================================================
const burger = document.getElementById('burger');
const mobileMenu = document.getElementById('mobileMenu');
if (burger) {
  burger.addEventListener('click', () => {
    const open = mobileMenu.classList.toggle('open');
    burger.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  mobileMenu.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
      burger.setAttribute('aria-expanded', 'false');
    });
  });
}

// ===========================================================
// Animated stat counter
// ===========================================================
const statNums = document.querySelectorAll('.stat__num[data-target]');
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const statIo = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const target = parseInt(el.getAttribute('data-target'), 10);
      const suffix = el.getAttribute('data-suffix') || '';

      if (prefersReducedMotion) {
        el.textContent = target + suffix;
        statIo.unobserve(el);
        return;
      }

      let current = 0;
      const duration = 1200;
      const stepTime = 16;
      const steps = duration / stepTime;
      const increment = target / steps;
      const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
          el.textContent = target + suffix;
          clearInterval(timer);
        } else {
          el.textContent = Math.floor(current) + suffix;
        }
      }, stepTime);
      statIo.unobserve(el);
    }
  });
}, { threshold: 0.5 });
statNums.forEach(el => statIo.observe(el));

// ===========================================================
// Custom cursor (desktop only, purely decorative)
// ===========================================================
const cursorDot = document.getElementById('cursorDot');
if (cursorDot && window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
  window.addEventListener('mousemove', (e) => {
    cursorDot.style.opacity = '1';
    cursorDot.style.left = e.clientX + 'px';
    cursorDot.style.top = e.clientY + 'px';
  });
  document.querySelectorAll('a, button').forEach(el => {
    el.addEventListener('mouseenter', () => {
      cursorDot.style.width = '30px';
      cursorDot.style.height = '30px';
      cursorDot.style.background = 'rgba(124,77,255,0.12)';
    });
    el.addEventListener('mouseleave', () => {
      cursorDot.style.width = '16px';
      cursorDot.style.height = '16px';
      cursorDot.style.background = 'transparent';
    });
  });
}
